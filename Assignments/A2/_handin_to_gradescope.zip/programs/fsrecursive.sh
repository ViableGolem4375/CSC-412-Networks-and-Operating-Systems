#! /usr/bin/env bash

# ./build.sh ../fio/fio.c

# ./fsrecursive | ./lowercase | ./mismatch > fsrecursion_unique_output.text