// application.cpp
#include "application.h"
#include <random>
#include <chrono>
#include <thread>
#include <iostream>
#include <unistd.h>
#include <sys/stat.h>

#include <vector>
#include <cstdlib>
#include <ctime>
#include <mutex>
#include <fstream>
#include <iomanip>

int** grid;
int NUM_ROWS, NUM_COLS;
int MAX_NUM_TRAVELER_THREADS;
int numLiveThreads = 0;
std::vector<InklingInfo> info;
bool DRAW_COLORED_TRAVELER_HEADS = true;
int MAX_LEVEL = 50;
int MAX_ADD_INK = 10;
int REFILL_INK = 10;
int redLevel = 20, greenLevel = 10, blueLevel = 40;
std::mutex redLock, blueLock, greenLock, blueCellLock, redCellLock, greenCellLock;
const int MIN_SLEEP_TIME = 30000;
int producerSleepTime = 100000;
int inklingSleepTime = 1000000;

void displayGridPane(void) {
    std::lock_guard<std::mutex> lock(displayLock); // Lock the mutex
    drawGridAndInklingsASCII(grid, NUM_ROWS, NUM_COLS, info);
}

void displayStatePane(void) {
    std::lock_guard<std::mutex> lock(displayLock); // Lock the mutex
    drawState(numLiveThreads, redLevel, greenLevel, blueLevel);
}

bool acquireRedInk(int theRed) {
    std::lock_guard<std::mutex> lock(redLock);
    bool ok = false;
    if (redLevel >= theRed) {
        redLevel -= theRed;
        ok = true;
    }
    return ok;
}

bool acquireGreenInk(int theGreen) {
    std::lock_guard<std::mutex> lock(greenLock); // Lock the mutex
	bool ok = false;
	if (greenLevel >= theGreen)
	{
		greenLevel -= theGreen;
		ok = true;
	}
	return ok;
}

bool acquireBlueInk(int theBlue) {
    std::lock_guard<std::mutex> lock(blueLock); // Lock the mutex
	bool ok = false;
	if (blueLevel >= theBlue)
	{
		blueLevel -= theBlue;
		ok = true;
	}
	return ok;
}

bool refillRedInk(int theRed) {
    std::lock_guard<std::mutex> lock(redLock);
    bool ok = false;
    if (redLevel + theRed <= MAX_LEVEL) {
        redLevel += theRed;
        ok = true;
    }
    return ok;
}

bool refillGreenInk(int theGreen) {
    std::lock_guard<std::mutex> lock(greenLock); // Lock the mutex
	bool ok = false;
	if (greenLevel + theGreen <= MAX_LEVEL)
	{
		greenLevel += theGreen;
		ok = true;
	}
	return ok;
}

bool refillBlueInk(int theBlue) {
    std::lock_guard<std::mutex> lock(blueLock); // Lock the mutex
	bool ok = false;
	if (blueLevel + theBlue <= MAX_LEVEL)
	{
		blueLevel += theBlue;
		ok = true;
	}
	return ok;
}

void speedupProducers(void) {
    int newSleepTime = (8 * producerSleepTime) / 10;
    if (newSleepTime > MIN_SLEEP_TIME) {
        producerSleepTime = newSleepTime;
    }
}

void slowdownProducers(void) {
    producerSleepTime = (12 * producerSleepTime) / 10;
}

void createLogFolder() {
    const char* logFolder = "logFolder";
    mkdir(logFolder, 0755);
}

std::string getCurrentTime() {
    auto now = std::chrono::system_clock::now();
    auto in_time_t = std::chrono::system_clock::to_time_t(now);
    auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(now.time_since_epoch()) % 1000;

    std::stringstream ss;
    ss << std::put_time(std::localtime(&in_time_t), "%H:%M:%S")
       << '.' << std::setfill('0') << std::setw(3) << ms.count();
    return ss.str();
}

void logInklingAction(const InklingInfo& inkling, const std::string& action) {
    std::ofstream logFile;
    std::string fileName = "logFolder/inkling" + std::to_string(inkling.id) + ".txt";
    logFile.open(fileName, std::ios_base::app);
    logFile << getCurrentTime() << ",inkling" << inkling.id << ',' << inkling.color << ',' << action << '\n';
    logFile.close();
    chmod(fileName.c_str(), 0755); // Set file permissions to 0755
}

void cleanupAndQuit(const std::string& msg) {
    std::cout << "Somebody called quits, goodbye sweet digital world, this was their message: \n" << msg;
    for (int i = 0; i < NUM_ROWS; i++) {
        delete[] grid[i];
    }
    delete[] grid;
    exit(0);
}

void initializeApplication(void) {
    grid = new int*[NUM_ROWS];
    for (int i = 0; i < NUM_ROWS; i++) {
        grid[i] = new int[NUM_COLS];
    }

    std::random_device myRandDev;
    std::default_random_engine myEngine(myRandDev());

    for (int i = 0; i < NUM_ROWS; i++) {
        for (int j = 0; j < NUM_COLS; j++) {
            grid[i][j] = 0;
        }
    }

    std::uniform_int_distribution<int> distRow(1, NUM_ROWS - 2);
    std::uniform_int_distribution<int> distCol(1, NUM_COLS - 2);
    std::uniform_int_distribution<int> distType(0, NUM_TRAV_TYPES - 1);

    for (int i = 0; i < MAX_NUM_TRAVELER_THREADS; ++i) {
        int x, y;
        do {
            x = distRow(myEngine);
            y = distCol(myEngine);
        } while (grid[x][y] != 0);

        InklingType type = static_cast<InklingType>(distType(myEngine));
        InklingInfo inked = {type, x, y, EAST, true, 100};
        info.push_back(inked);
        grid[x][y] = 1; // Mark the grid cell as occupied
    }
}

void threadFunction(InklingInfo* inkling) {
    while (inkling->active) {
        if (checkIfInCorner(inkling)) {
            getNewDirection(inkling);
        }

        int moveAmount = 1;

        if (checkEnoughInk(inkling, moveAmount)) {
            switch (inkling->dir) {
                case NORTH:
                    if (inkling->row > 0) inkling->row--;
                    break;
                case SOUTH:
                    if (inkling->row < NUM_ROWS - 1) inkling->row++;
                    break;
                case WEST:
                    if (inkling->col > 0) inkling->col--;
                    break;
                case EAST:
                    if (inkling->col < NUM_COLS - 1) inkling->col++;
                    break;
                default:
                    break;
            }

            grid[inkling->row][inkling->col] = 1;
            logInklingAction(*inkling, "move");
        } else {
            inkling->active = false;
            logInklingAction(*inkling, "terminate");
        }

        std::this_thread::sleep_for(std::chrono::microseconds(inklingSleepTime));
    }
}

void getNewDirection(InklingInfo* inkling) {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<int> dist(0, NUM_TRAVEL_DIRECTIONS - 1);
    inkling->dir = static_cast<TravelDirection>(dist(gen));
}

bool checkIfInCorner(InklingInfo* inkling) {
    return (inkling->row == 0 && inkling->col == 0) || 
           (inkling->row == 0 && inkling->col == NUM_COLS - 1) || 
           (inkling->row == NUM_ROWS - 1 && inkling->col == 0) || 
           (inkling->row == NUM_ROWS - 1 && inkling->col == NUM_COLS - 1);
}

bool checkEnoughInk(InklingInfo* inkling, int moveAmount) {
    std::lock_guard<std::mutex> lock(inkling->type == RED_TRAV ? redLock : 
                                     inkling->type == GREEN_TRAV ? greenLock : blueLock);
    if (inkling->inkLevel >= moveAmount) {
        inkling->inkLevel -= moveAmount;
        return true;
    }
    return false;
}

void redColorThreadFunc() {
    while (true) {
        std::this_thread::sleep_for(std::chrono::microseconds(producerSleepTime));
        std::lock_guard<std::mutex> lock(redLock);
        if (redLevel < MAX_LEVEL) {
            redLevel += REFILL_INK;
        }
    }
}

void greenColorThreadFunc() {
    while (true) {
        std::this_thread::sleep_for(std::chrono::microseconds(producerSleepTime));
        std::lock_guard<std::mutex> lock(greenLock);
        if (greenLevel < MAX_LEVEL) {
            greenLevel += REFILL_INK;
        }
    }
}

void blueColorThreadFunc() {
    while (true) {
        std::this_thread::sleep_for(std::chrono::microseconds(producerSleepTime));
        std::lock_guard<std::mutex> lock(blueLock);
        if (blueLevel < MAX_LEVEL) {
            blueLevel += REFILL_INK;
        }
    }
}