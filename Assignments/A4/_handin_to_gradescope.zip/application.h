// application.h
#ifndef APPLICATION_H
#define APPLICATION_H

#include <vector>
#include <mutex>
#include "ascii_art.h"


extern int** grid;
extern int NUM_ROWS, NUM_COLS;
extern int MAX_NUM_TRAVELER_THREADS;
extern int numLiveThreads;
extern std::vector<InklingInfo> info;
extern bool DRAW_COLORED_TRAVELER_HEADS;
extern int MAX_LEVEL;
extern int MAX_ADD_INK;
extern int REFILL_INK;
extern int redLevel, greenLevel, blueLevel;
extern std::mutex redLock, blueLock, greenLock, blueCellLock, redCellLock, greenCellLock;
extern const int MIN_SLEEP_TIME;
extern int producerSleepTime;
extern int inklingSleepTime;

void displayGridPane(void);
void displayStatePane(void);
void initializeApplication(void);
void threadFunction(InklingInfo* inkling);
void getNewDirection(InklingInfo* inkling);
bool checkIfInCorner(InklingInfo* inkling);
void redColorThreadFunc();
void greenColorThreadFunc();
void blueColorThreadFunc();
bool checkEnoughInk(InklingInfo* inkling, int moveAmount);
bool acquireRedInk(int theRed);
bool acquireGreenInk(int theGreen);
bool acquireBlueInk(int theBlue);
bool refillRedInk(int theRed);
bool refillGreenInk(int theGreen);
bool refillBlueInk(int theBlue);
void speedupProducers(void);
void slowdownProducers(void);
void createLogFolder();
std::string getCurrentTime();
void logInklingAction(const InklingInfo& inkling, const std::string& action);
void cleanupAndQuit(const std::string& msg);

#endif // APPLICATION_H