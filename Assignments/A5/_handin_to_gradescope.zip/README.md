# URI CSC 412 - Fall 24 Assignment

This is where the stencil code for this assignments lives :)
