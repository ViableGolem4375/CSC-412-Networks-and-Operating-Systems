#! /usr/bin/env bash

### TODO:

# get filename to compile from command line (how do you read just the firsy argument?)

# compile lab1.c to lab1 (you did something similar in Lab 0)

# get the arguments passed when running lab1.sh (*this is the hard part)

# run the lab1 program with those arguments (*this is the other hard part)

filename=$1
shift
output="$@"

gcc -o lab1 "$filename"

./lab1 $output