# URI CSC 412 - Fall 24 Lab

This is where the stencil code for the lab lives :)
