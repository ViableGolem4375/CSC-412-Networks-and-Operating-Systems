## Link to Chat Logs: 

https://chatgpt.com/share/6749c198-5f54-8013-a45d-56be74fff6d9