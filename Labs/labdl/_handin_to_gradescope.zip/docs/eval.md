# Eval (all team members)

Copy, paste, and complete the evaluation for every team member. You should do one for yourself, as a self-eval.

### Group Member's Name

Kevin Lattuada

The answers for each question should be a number 1--5:

1 Never, 2 Rarely, 3 Sometimes, 4 Usually, 5 Always

#### Questions

1. Did your partner come to the scheduled meetings on time and ready to work?

Answer: 5


2. Did your partner read the lab handout before coming to the scheduled meetings, showing up wither with specific questions or ready to contribute?

Answer: 5


3. Did your partner cooperatively follow the pair programming model (rotating roles of driver and navigator, questioning and making observations as the navigator)?

Answer: 5


4. Did your partner contribute fully, fairly, and actively, to the best of his or her ability, to the completion of the lab?

Answer: 5


5. Was your partner's participation professional and cooperative overall?

Answer: 5

#### Open Feedback

Please write 2-3 sentences evaluation of the team member. What they did good and what they need to work on?

I think my partner did a great job working with me on this assignment. He was helpful with working through problems and timely with completing work on time and correctly along with doing a good job of correcting me on things I misunderstood.

### Group Member's Name

Matthew Langton

The answers for each question should be a number 1--5:

1 Never, 2 Rarely, 3 Sometimes, 4 Usually, 5 Always

#### Questions

1. Did your partner come to the scheduled meetings on time and ready to work?

Answer: 5


2. Did your partner read the lab handout before coming to the scheduled meetings, showing up wither with specific questions or ready to contribute?

Answer: 5


3. Did your partner cooperatively follow the pair programming model (rotating roles of driver and navigator, questioning and making observations as the navigator)?

Answer: 5


4. Did your partner contribute fully, fairly, and actively, to the best of his or her ability, to the completion of the lab?

Answer: 5


5. Was your partner's participation professional and cooperative overall?

Answer: 5

#### Open Feedback

Please write 2-3 sentences evaluation of the team member. What they did good and what they need to work on?

I think that I also did a good job completing work in a timely manner and working through issues that arose. I made sure to be communicative with my partner to make sure everything got done on time and correctly. If there is anything I think I could do better it would probably just be reading assignment handouts as there were a few things I misunderstood at the beginning of this assignment which I was corrected on by my partner.