#!/bin/bash

# start server.exe in the background
./server &

# start client.exe in the background
./client &

exit 0