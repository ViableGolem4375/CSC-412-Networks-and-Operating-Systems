### Add a Detailed explanation of how you fixed the Kernel Code
